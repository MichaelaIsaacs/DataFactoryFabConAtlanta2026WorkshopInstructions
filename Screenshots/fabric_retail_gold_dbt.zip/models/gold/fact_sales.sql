with order_items as (
  select * from {{ ref('stg_retail_order_items') }}
),
customers as (
  select customer_id, customer_name, loyalty_tier from {{ ref('dim_customer') }}
),
products as (
  select product_id, product_name, category, list_price, cost, unit_margin from {{ ref('dim_product') }}
)
select
  oi.order_item_id,
  oi.order_id,
  oi.order_date,
  oi.customer_id,
  c.customer_name,
  c.loyalty_tier,
  oi.product_id,
  p.product_name,
  p.category,
  oi.quantity,
  oi.unit_price,
  oi.discount_pct,
  (oi.quantity * oi.unit_price) as gross_sales_amount,
  (oi.quantity * oi.unit_price) * (coalesce(oi.discount_pct, 0) / 100.0) as discount_amount,
  coalesce(
    oi.line_total,
    (oi.quantity * oi.unit_price) - ((oi.quantity * oi.unit_price) * (coalesce(oi.discount_pct, 0) / 100.0))
  ) as net_sales_amount,
  (oi.quantity * p.unit_margin) as gross_margin_amount,
  oi.RevenueTier
from order_items oi
left join customers c on oi.customer_id = c.customer_id
left join products p on oi.product_id = p.product_id
