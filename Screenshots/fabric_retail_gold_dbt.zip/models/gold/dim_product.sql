with ranked as (
  select
    product_id,
    product_name,
    category,
    description,
    list_price,
    cost,
    unit_of_measure,
    weight_lbs,
    image_url,
    (list_price - cost) as unit_margin,
    row_number() over (partition by product_id order by product_name) as rn
  from {{ ref('stg_retail_products') }}
)
select
  product_id,
  product_name,
  category,
  description,
  list_price,
  cost,
  unit_of_measure,
  weight_lbs,
  image_url,
  unit_margin
from ranked
where rn = 1
