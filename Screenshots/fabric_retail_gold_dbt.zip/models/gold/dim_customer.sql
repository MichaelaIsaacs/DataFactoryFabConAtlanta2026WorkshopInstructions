with ranked as (
  select
    customer_id,
    customer_name,
    first_name,
    last_name,
    email,
    phone_clean,
    address,
    city,
    state,
    zip_code,
    registration_date,
    loyalty_tier,
    row_number() over (partition by customer_id order by registration_date desc) as rn
  from {{ ref('stg_retail_customer') }}
)
select
  customer_id,
  customer_name,
  first_name,
  last_name,
  email,
  phone_clean,
  address,
  city,
  state,
  zip_code,
  registration_date,
  loyalty_tier
from ranked
where rn = 1
