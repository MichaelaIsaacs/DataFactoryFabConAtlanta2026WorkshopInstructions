with src as (
  select *
  from {{ source('silver', 'retail_order_items') }}
  where {{ is_not_deleted('_is_deleted') }}
)
select
  order_item_id,
  order_id,
  customer_id,
  store_id,
  product_id,
  cast(order_date as date) as order_date,
  cast(quantity as int) as quantity,
  cast(unit_price as decimal(18,2)) as unit_price,
  cast(discount_pct as decimal(18,2)) as discount_pct,
  cast(line_total as decimal(18,2)) as line_total,
  RevenueTier,
  _ingestion_timestamp,
  _source_file,
  _batch_id
from src
