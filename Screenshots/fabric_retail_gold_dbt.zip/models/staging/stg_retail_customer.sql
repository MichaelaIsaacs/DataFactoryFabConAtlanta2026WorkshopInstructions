with src as (
  select *
  from {{ source('silver', 'retail_customer') }}
  where {{ is_not_deleted('_is_deleted') }}
)
select
  customer_id,
  first_name,
  last_name,
  concat(first_name, ' ', last_name) as customer_name,
  lower(email) as email,
  phone,
  -- Use provided Clean_PhoneNumbers when present; fall back to raw phone.
  coalesce(Clean_PhoneNumbers, phone) as phone_clean,
  address,
  city,
  state,
  zip_code,
  registration_date,
  loyalty_tier,
  _ingestion_timestamp,
  _source_file,
  _batch_id
from src
