with src as (
  select *
  from {{ source('silver', 'retail_products') }}
  where {{ is_not_deleted('_is_deleted') }}
)
select
  product_id,
  name as product_name,
  category,
  description,
  cast(unit_price as decimal(18,2)) as list_price,
  cast(cost as decimal(18,2)) as cost,
  unit_of_measure,
  cast(weight_lbs as decimal(18,4)) as weight_lbs,
  image_url,
  _ingestion_timestamp,
  _source_file,
  _batch_id
from src
