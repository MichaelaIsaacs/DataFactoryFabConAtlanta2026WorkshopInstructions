{% macro is_not_deleted(col_name) -%}
  -- Handles _is_deleted as 0/1, 'true'/'false', 'Y'/'N', NULL (all varchar).
  coalesce(
    case
      when {{ col_name }} is null then 0
      when {{ col_name }} in ('1', 'true', 'TRUE', 'True', 'Y', 'y') then 1
      else 0
    end
  , 0) = 0
{%- endmacro %}
